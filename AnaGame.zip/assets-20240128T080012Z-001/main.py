#Import Required Libraries
import pygame
import random
import sys

#Initialize PyGame
pygame.init()

#Setting Screen Dimensions
screen_width = 1000
screen_height = 500

#Score
score = 0 
#Number of lives each player gets
player_lives = 3
#Setting Fonts
font = pygame.font.Font(None,36)
game_over_font = pygame.font.Font(None, 64)

#Adding The Dimensions To The Screen
screen = pygame.display.set_mode((screen_width, screen_height))
#Setting The Screen Title
pygame.display.set_caption("Realm Quest")

#Setting The Background
background_image = pygame.image.load("assets/assets/background.png")
#Transforming The Image to Fit The Screen
background_image = pygame.transform.scale(background_image,(screen_width, screen_height))
#Coordinates of background
bg_x = 0
#Background Speed
speed_increase_rate = 0

enemies = []
player_bullets=[]
#Creating a Character Class
#Class is folder to run similar functions all the time
#Like a blueprint
#Makes it easy to change Stuff
class Character:
    
    #Contructor, Runs on its own
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.img = pygame.image.load("assets/assets/player1.png")
        #Transforms the image
        self.img = pygame.transform.scale(self.img, (100,100))
        #Forms a rectangle around the image
        self.rect = self.img.get_rect()
        self.rect.center = (x,y)
        #Changes the Sprite Image
        self.run_animation_count = 0
        #Defines the Sprite List
        self.img_list= ["assets/assets/player1.png", "assets/assets/player2.png", "assets/assets/player3.png", "assets/assets/player4.png"]
        self.is_jump = False
        #Player Goes Up for 15 Counts
        self.jump_count = 15
        self.bullet_img = 'assets/assets/bullet.png'
    
    #Defines the draw function to get a character to print on screen
    def draw(self):
        self.rect.center = (self.x, self.y)
        screen.blit(self.img, self.rect)
    
    #Defines the Animation Function
    def run_animation_player(self):
        #Checks if the player is jumping
        if(not self.is_jump):
        #Changes the image to the given sprite
            self.img = pygame.image.load(self.img_list[int(self.run_animation_count)])
            self.img = pygame.transform.scale(self.img,(42,64))
            #Changes the sprite at the given rate
            self.run_animation_count+=0.5
            #To Make Sure That The Count Does Not Exceed 3
            self.run_animation_count = self.run_animation_count%4
    
    #Creating a function to implement jump
    def jump(self):
        if (self.jump_count>-15):
            n = 1
            if (self.jump_count<0):
                n = -1
            #Going Up at The Graph of Squares
            self.y -= ((self.jump_count**2)/10)*n
            #Makes the plater go down
            self.jump_count -= 1
        else: 
            #player wont jump after the function is over
            self.is_jump = False
            self.jump_count = 15
            #Resets back to the original y function
            self.y = 420

    #Defining a funtion to shoot bullets with the co-ordinates of the bullets spawning
    def shoot(self):
        bullet = Bullet(self.x+5, self.y-18, self.bullet_img)
        player_bullets.append(bullet)

#Creating the class for the enemy        
class Enemy:
    
    #Creating the enemy Sprite
    #Contructor, Runs on its own
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.img = pygame.image.load("assets/assets/enemy1.png")
        #Transforms the image
        self.img = pygame.transform.scale(self.img, (75,75))
        #Forms a rectangle around the image
        self.rect = self.img.get_rect()
        self.rect.center = (x,y)
        #Changes the Sprite Image
        self.run_animation_count = 0
        #Defines the Sprite List
        self.img_list= ["assets/assets/enemy1.png", "assets/assets/enemy2.png", "assets/assets/enemy3.png"]
        self.bullet_img = 'assets/assets/bullet.png'
    
    #Defines the draw function to get a character to print on screen
    def draw(self):
        self.rect.center = (self.x, self.y)
        screen.blit(self.img, self.rect)
    
    #Defines the Animation Function
    def run_animation_enemy(self):
        #Changes the image to the given sprite
        self.img = pygame.image.load(self.img_list[int(self.run_animation_count)])
        self.img = pygame.transform.scale(self.img,(75,75))
        #Changes the sprite at the given rate
        self.run_animation_count+=0.5
        #To Make Sure That The Count Does Not Exceed 3
        self.run_animation_count = self.run_animation_count%3

#Creating the bullet Class
class Bullet:
    
    #Creating a function for the bullet sprite
    def __init__(self,x,y,img):
        self.x = x
        self.y = y
        self.img = pygame.image.load(img)
        self.img = pygame.transform.scale(self.img, (15,15))
        self.rect = self.img.get_rect()
        self.rect.center = (x,y)

    #Defines the draw function to get a character to print on screen
    def draw(self):
        self.rect.center = (self.x,self.y)
        screen.blit(self.img, self.rect)

    #Defines the way the bullet should move
    def move(self, vel):
        self.x += vel
    
    #Defines screen limit of the bullet
    def off_screen(self):
        return(self.x<=0 or self.x>=screen_width)

#Setting a Running Clock For The Game
player = Character(100,420)
running = True
clock = pygame.time.Clock()
last_enemy_spawn_time = pygame.time.get_ticks()

#Main Game Loop
while running:
    score += 1
    #Gets User Input
    for event in pygame.event.get():
        #Allowing The Game To Quit
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                player.is_jump = True
            if event.key == pygame.K_RIGHT:
                player.shoot()
    #Changes the speed of the image
    speed_increase_rate+=0.006
    #Changes the images of the background to make it move
    bg_x -= (10+speed_increase_rate)
    #As the first image leaves the screen, it is reset to go back to its original position to make an infinite loop
    if bg_x <= -screen_width:
        bg_x = 0
    #Printing The Background on The Screen
    screen.blit(background_image,(bg_x,0))
    screen.blit(background_image,(bg_x+screen_width,0))

    #Setting Enemy Time
    current_time = pygame.time.get_ticks()
    #Checks the difference between last enemy spawn time and current
    if current_time - last_enemy_spawn_time >= 3000:
        #Creates A Random Number
        if random.randint(0,100) < 3:
            enemy_x  = screen_width + 900
            enemy_y = 396
            enemy = Enemy(enemy_x, enemy_y)
            enemies.append(enemy)
            #Updates the enemy spawn time
            last_enemy_spawn_time = current_time
    #Implementing Enemies
    for enemy in enemies: 
        enemy.x -= (15 + speed_increase_rate)
        enemy.draw()
        enemy.run_animation_enemy()

        #Setting Up Lives and Enemy Despawns
        if enemy.rect.colliderect(player.rect):
            speed_increase_rate = 0
            player_lives -= 1
            enemies.remove(enemy)

        #Setting up Killing Enemies and Adding Scores
        for bullet in player_bullets:
            if pygame.Rect.colliderect(enemy.rect, bullet.rect):
                player_bullets.remove(bullet)
                enemies.remove(enemy)
                score += 10

    #Making the Bullets Move or Hide if Off-Screen
    for bullet in player_bullets:
        if(bullet.off_screen()):
            player_bullets.remove(bullet)
        else:
            bullet.draw()
            bullet.move(10)

    #Game Over Text and Exit
    if player_lives <= 0:
        game_over_text = game_over_font.render("Happy Birthday Ana!!", True, (255, 255, 255))
        screen.blit(game_over_text,(screen_width//2 -120, screen_height//2))
        pygame.display.update()
        pygame.time.wait(2000)
        pygame.quit()
        sys.exit()

    #Display the number of lives a player has left and also specify the color of the text
    #F String
    live_text = font.render(f"Times Before You Fall For Me:   {player_lives}", True, (0,0,0))
    screen.blit(live_text,(20,30))
    #Display the score and also specify the color
    score_text = font.render(f"Shoot Me With Hearts Before I Make You Fall In Love   Score:   {score}", True, (0,0,0))
    screen.blit(score_text, (20, 10))

    #Checks if jump is activated
    if (player.is_jump):
        player.jump()
    #Draws The Image on Screen
    player.draw()
    #Calls The Animation Function
    player.run_animation_player()
    #Updating The Display To Show Changes
    pygame.display.update()
    #Frames Per Second// Runs The Loop Per Second
    clock.tick(30)
pygame.quit()
